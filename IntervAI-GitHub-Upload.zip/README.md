# IntervAI

This repository contains the supplied full-stack starter project archive and the current standalone Java backend with its frontend pages.

## Standalone Java backend

Requirements: Java 17 or newer.

On Windows, run `java-backend\run-java-backend.bat`, or run these commands from `java-backend`:

```text
javac IntervAIJavaBackend.java
java IntervAIJavaBackend
```

Open `http://127.0.0.1:8000/` for the landing page or `http://127.0.0.1:8000/login.html` for sign in. The standalone backend stores accounts and sessions in memory; they are cleared when the server stops. Do not use it as-is for production.

## Supplied project

`IntervAI_Project.zip` is the project archive as provided. It contains its own README and setup instructions.
